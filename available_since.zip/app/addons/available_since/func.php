<?php

if (!defined('BOOTSTRAP')) { die('Access denied'); }

function fn_available_since_update_product_pre(&$product_data, $product_id, $lang_code, $can_update)
{
    if (!empty($product_data['demo_avail_since'])) {
        $product_data['demo_avail_since'] = fn_parse_date($product_data['demo_avail_since']);
    }
}
